//
//  SwiftConstant.swift
//
//  Created by RahulKumar on 28/02/18.
//

import Foundation

// Color Constants
let kColorNavigationBar = "#36B1E5"


// Text Constants
let kTextNavigationBarChangePassword = "Change Password"
let kUsername = "username"
